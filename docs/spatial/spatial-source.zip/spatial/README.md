# Jeu spatial — port navigateur du programme original

Le fichier `original/miniprojet.cpp` est conservé octet pour octet depuis le dépôt de Mohamed Boubaker. `game/miniprojet.cpp` en est la version réglée pour le navigateur :
https://github.com/mohamed-boubaker/Licence-1-Project-/tree/main/jeu-spatial-cpp-grapic
Révision : `83ca430799dcae3511a642ef5a5b783587c9b77d`.
Les six images et la capture proviennent du même dépôt et ne sont pas modifiées.

## Exécution

`web/main_web.cpp` inclut le programme d'origine en renommant son `main` de bureau, puis appelle les fonctions C++ du projet `initWorld`, `draw`, `update`, `dScor` et `maxVitesseAlien` depuis une boucle Emscripten. Aucun moteur JavaScript de remplacement n'est utilisé. La simulation tourne à 60 mises à jour par seconde avec le `dt=0.1` d'origine.

La structure `World` est initialisée à zéro avant le premier appel à `initWorld` : le programme d'origine lit le rayon des rochers avant leur première affectation. Cette initialisation évite une lecture de mémoire indéfinie, en conservant une copie du fichier original. La pause, le nouvel essai et la remise à zéro sont ajoutés dans l'adaptateur. Le score d'origine (+10 / −5) est conservé. Un nouvel essai garde le score ; la remise à zéro efface le score de la session.

## Compilation

Installer et activer Emscripten 3.1.74, puis lancer :

```sh
bash build.sh
```

Le build utilise C++17 pour la version de Grapic vendue avec ce port. Il produit `../dist/spatial/spatial.js`, `.wasm` et `.data`. Héberger l'ensemble du dossier `dist/` du portfolio en HTTP(S).

## Bibliothèque et crédits

- Grapic : https://github.com/ucacaxm/grapic — révision `2e3e193e84676d33f9f4060b4d802137b655fb53`. Trois adaptations locales de Grapic initialisent le drapeau de fenêtre à zéro dans `.h`, utilisent la résolution logique pour inverser l’axe Y et transforment les coordonnées de souris vers cette résolution dans `.cpp`. Alexandre Meyer et Elodie Desseree, GPL v3 ou ultérieure ; voir les mentions dans les sources et `vendor/licenses/GPL-3.0.txt`.
- Police Roboto fournie par ce dépôt Grapic, copyright Google 2012, Apache 2.0. Copiée dans `game/data/ttf/` pour afficher le score. Licence dans `vendor/licenses/Apache-2.0.txt`.
- Les ressources du jeu conservent les crédits et conditions du projet d'origine ; voir `game/README.md`.
- Adaptation navigateur réalisée avec l'aide de ChatGPT.

## Tests

```sh
g++ -std=c++17 -Itests/stubs tests/test_core.cpp -o /tmp/test-spatial
/tmp/test-spatial
```

Les stubs remplacent uniquement les appels graphiques et les entrées pour tester les fonctions C++ du jeu sans fenêtre. Les tests couvrent 100 initialisations, la commande souris, les mouvements, les collisions, les scores, les réinitialisations et 10 000 mises à jour, ainsi que le suivi du curseur dans les deux sens et le freinage. Le même test est aussi compilable en WebAssembly pour Node.

Les tests du moteur et la compilation de la vraie bibliothèque Grapic ne remplacent pas une vérification visuelle du port dans un navigateur.

## Réglages du pilotage pour le navigateur

À la demande de Mohamed, les météorites se déplacent 20 fois plus vite. La poussée vers le curseur est renforcée, la vitesse est limitée à ±60 unités dans chaque axe et un amortissement de 0,82 par pas pendant le clic réduit les dépassements. Au relâchement, il passe à 0,95 pour conserver une glissade avant de ralentir. Ces réglages sont dans le C++ ; les collisions, les scores, les images et les parcours aléatoires restent ceux du projet. La zone de jeu utilise davantage de largeur et les informations passent sous le jeu sur les écrans intermédiaires.

## Agrandissement et plein écran

Le rendu SDL utilise une résolution logique constante de 600 × 600. Le drapeau de fenêtre de `winInit` est initialisé à zéro pour éviter une activation indéfinie du mode plein écran SDL. La conversion de l’axe Y dans Grapic utilise cette résolution logique, plutôt que les pixels du canevas agrandi. Les coordonnées de souris sont reconverties avec `SDL_RenderWindowToLogical`, afin de conserver une visée correcte après redimensionnement. En plein écran, le canevas reste carré et centré ; les marges utilisent le même fond sombre que le cadre.

La largeur affichée du carré est plafonnée par la hauteur visible de la fenêtre, en réservant la hauteur mesurée du titre et des commandes. Au lancement ou au redimensionnement pendant une partie, la page aligne le cadre dans la fenêtre pour le rendre visible en entier. Le bouton plein écran continue de centrer un carré adapté à la largeur et à la hauteur disponibles.

Les barres de titre, de commandes et de statut sont compactées pour agrandir légèrement le carré tout en gardant le jeu entier dans la fenêtre. La marge verticale réservée est de 16 pixels.
