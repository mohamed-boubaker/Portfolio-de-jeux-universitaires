#include <cassert>
#include <cmath>
#define main spatial_original_main
#include "../game/miniprojet.cpp"
#undef main

int main() {
    // Les stubs neutralisent uniquement l'affichage et contrôlent la souris.
    // Les fonctions C++ du jeu incluent les réglages de pilotage du navigateur.
    for (int seed = 0; seed < 100; ++seed) {
        srand(seed);
        World w{};
        initWorld(w);
        assert(w.nb_rocks == 12 && w.alien.p.x == 300 && w.alien.p.y == 30);
        assert(!collision(w) && !alienWin(w) && !nonwin(w));
        for (int i = 0; i < 12; ++i) {
            assert(w.rocks[i].radius >= 5 && w.rocks[i].radius <= 54);
            assert(w.rocks[i].speed >= 0.2f && w.rocks[i].speed <= 0.96f);
            assert(std::isfinite(w.rocks[i].pos.x));
        }
        initWorld(w);
        assert(!collision(w));
    }
    World w{};
    srand(42); initWorld(w);
    mouseDown = false;
    auto force = forceLauncher(w);
    assert(force.x == 0 && force.y == 0);
    mouseDown = true; pointerX = 400; pointerY = 530;
    force = forceLauncher(w);
    assert(force.x == 100 && force.y == 500);
    w.nb_rocks = 0;
    update(w, dt);
    assert(w.alien.p.x > 300 && w.alien.p.y > 30);
    mouseDown = false;
    // Atteindre la lune donne +10 puis replace le joueur au départ.
    initWorld(w); w.nb_rocks = 0;
    w.alien.p = w.moon.pos;
    w.alien.v = m_v(0, 0);
    update(w, dt);
    assert(w.scor == 10 && w.alien.p.x == 300 && w.alien.p.y == 30);
    // Collision : -5, puis nouveau parcours.
    initWorld(w); w.nb_rocks = 1;
    w.rocks[0].pos = w.alien.p + m_v(1, 0); w.rocks[0].radius = 20; w.rocks[0].speed = 0;
    assert(collision(w));
    update(w, dt);
    assert(w.scor == 5 && w.alien.p.x == 300 && w.alien.p.y == 30);
    // Sortie d'écran : -5 sans modifier les règles de score.
    initWorld(w); w.nb_rocks = 0; w.alien.p = m_v(-10, 100);
    assert(nonwin(w));
    update(w, dt);
    assert(w.scor == 0 && w.alien.p.x == 300 && w.alien.p.y == 30);
    // Mouvement des rochers et valeurs physiques finies en simulation longue.
    initWorld(w);
    const float rockX = w.rocks[0].pos.x;
    update(w, dt);
    assert(w.rocks[0].pos.x > rockX);
    for (int i = 0; i < 10000; ++i) {
        update(w, dt); maxVitesseAlien(w);
        assert(std::isfinite(w.alien.p.x) && std::isfinite(w.alien.p.y));
    }
    // Réactivité réelle : parcourir plus de 150 pixels en une demi-seconde,
    // rejoindre la visée sans la dépasser et pouvoir repartir en sens inverse.
    initWorld(w); w.nb_rocks = 0; w.moon.pos = m_v(0, 550);
    w.alien.p = m_v(300, 100); w.alien.v = m_v(0, 0);
    mouseDown = true; pointerX = 300; pointerY = 400;
    for (int i = 0; i < 30; ++i) update(w, dt);
    assert(w.alien.p.y > 250 && w.alien.p.y < 400);
    for (int i = 0; i < 90; ++i) update(w, dt);
    assert(std::abs(w.alien.p.y - 400) < 1);
    pointerY = 100;
    for (int i = 0; i < 60; ++i) update(w, dt);
    assert(w.alien.p.y < 125 && w.alien.p.y >= 100);
    // Au relâchement, une glissade persiste puis se dissipe progressivement.
    mouseDown = false; w.alien.v = m_v(-60, 60);
    const Vec beforeRelease = w.alien.p;
    for (int i = 0; i < 10; ++i) update(w, dt);
    assert(w.alien.v.x < -30 && w.alien.v.y > 30);
    assert(beforeRelease.x - w.alien.p.x > 40 && w.alien.p.y - beforeRelease.y > 40);
    for (int i = 0; i < 50; ++i) update(w, dt);
    assert(std::abs(w.alien.v.x) < 3 && std::abs(w.alien.v.y) < 3);
    std::cout << "Spatial : score, collisions, simulation longue, vitesse des rochers, suivi du curseur dans les deux sens et freinage OK\n";
}
