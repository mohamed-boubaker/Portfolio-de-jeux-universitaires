#pragma once
#include <ctime>
const int SDL_BUTTON_LEFT = 1, SDLK_r = 114;
namespace grapic {
struct Image {};
inline bool mouseDown = false;
inline int pointerX = 0, pointerY = 0;
inline bool isMousePressed(int) { return mouseDown; }
inline void mousePos(int& x, int& y) { x = pointerX; y = pointerY; }
inline bool isKeyPressed(int) { return false; }
inline void color(int,int,int) {}
inline void circleFill(float,float,float) {}
inline void line(float,float,float,float) {}
inline void image_draw(const Image&,float,float,float,float) {}
inline Image image(const char*) { return {}; }
inline void fontSize(int) {}
inline void print(int,int,int) {}
inline void winInit(const char*,int,int) {}
inline void setKeyRepeatMode(bool) {}
inline void backgroundColor(int,int,int) {}
inline void winClear() {}
inline bool winDisplay() { return true; }
inline void pressSpace() {}
inline void winQuit() {}
}
