#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${EMXX:=em++}"
mkdir -p ../dist/spatial
"$EMXX" vendor/grapic/Grapic.cpp web/main_web.cpp \
  -Ivendor/grapic -std=c++17 -O2 \
  -sUSE_SDL=2 -sUSE_SDL_IMAGE=2 '-sSDL2_IMAGE_FORMATS=["png"]' \
  -sUSE_SDL_TTF=2 -sALLOW_MEMORY_GROWTH=1 -sASSERTIONS=1 \
  -sENVIRONMENT=web -sINVOKE_RUN=0 \
  '-sEXPORTED_RUNTIME_METHODS=["callMain"]' \
  --preload-file game/data@data -o ../dist/spatial/spatial.js
