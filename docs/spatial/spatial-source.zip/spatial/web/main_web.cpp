// Boucle navigateur autour du jeu universitaire C++ / Grapic et de ses réglages.
#include <ctime>
#include <emscripten.h>
#define main spatial_desktop_main
#include "../game/miniprojet.cpp"
#undef main

// La valeur initiale des rayons est lue par initWorld avant leur affectation.
// Initialiser World à zéro évite la lecture de mémoire indéfinie du main bureau.
static World world{};
static bool paused = false;
static int attempts = 1, wins = 0;
static Uint32 lastTick;
static double accumulated = 0;

EM_JS(void, publish_state, (int score, int attempt, int winCount, int state), {
    globalThis.spatialState?.(score, attempt, winCount, state);
});

extern "C" {
EMSCRIPTEN_KEEPALIVE void spatial_pause() {
    paused = !paused;
    lastTick = SDL_GetTicks();
    publish_state(world.scor, attempts, wins, paused ? 1 : 0);
}
EMSCRIPTEN_KEEPALIVE void spatial_restart() {
    initWorld(world);
    ++attempts;
    lastTick = SDL_GetTicks();
    publish_state(world.scor, attempts, wins, paused ? 1 : 0);
}
EMSCRIPTEN_KEEPALIVE void spatial_reset() {
    initWorld(world); world.scor = 0; attempts = 1; wins = 0; paused = false;
    lastTick = SDL_GetTicks();
    publish_state(0, 1, 0, 0);
}
EMSCRIPTEN_KEEPALIVE float spatial_value(int field) {
    switch (field) {
        case 0: return world.alien.p.x;
        case 1: return world.alien.p.y;
        case 2: return world.scor;
        case 3: return world.nb_rocks;
        case 4: return paused;
    }
    return -1;
}
}

static void frame() {
    Grapic::singleton().manageEvent();
    SDL_RenderSetLogicalSize(Grapic::singleton().renderer(), DIMW, DIMW);
    // La cadence du navigateur remplace la boucle bloquante du main d'origine.
    winClear();
    draw(world);
    const Uint32 now = SDL_GetTicks();
    accumulated += std::min<Uint32>(now - lastTick, 100);
    lastTick = now;
    if (paused) accumulated = 0;
    while (accumulated >= 1000.0 / 60.0) {
        accumulated -= 1000.0 / 60.0;
        const int before = world.scor;
        update(world, dt);
        maxVitesseAlien(world);
        if (world.scor != before) {
            ++attempts;
            if (world.scor > before) ++wins;
            publish_state(world.scor, attempts, wins, world.scor > before ? 2 : 3);
        }
    }
    dScor(world.scor);
    winDisplay();
}

int main() {
    srand(time(nullptr));
    winInit("Jeu spatial", DIMW, DIMW);
    SDL_RenderSetLogicalSize(Grapic::singleton().renderer(), DIMW, DIMW);
    setKeyRepeatMode(true);
    initWorld(world);
    world.scor = 0;
    world.img_alien = image("data/alien.png");
    world.img_rocks = image("data/rocks.png");
    world.img_rock1 = image("data/rock1.png");
    world.img_rock2 = image("data/rock2.png");
    world.img_moon = image("data/moon.png");
    world.img_background = image("data/space_background.png");
    backgroundColor(20, 45, 55);
    lastTick = SDL_GetTicks();
    publish_state(0, 1, 0, 0);
    emscripten_set_main_loop(frame, 0, 1);
}
