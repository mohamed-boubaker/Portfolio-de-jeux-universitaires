import modele.jeu.Jeu;
import modele.plateau.*;
import modele.item.*;
import vuecontroleur.ImagePanel;
import vuecontroleur.Assets;
import java.awt.image.BufferedImage;

public class TestModel {
  public static void main(String[] args) {
    Jeu jeu = new Jeu(false);
    Plateau plateau = jeu.getPlateau();
    assert plateau.getCases().length == 16;
    assert plateau.getCases()[6][6].getMachine() instanceof ZoneLivraison;
    jeu.press(0,0);
    assert plateau.getCases()[0][0].getMachine() instanceof Tapis;
    Direction first = plateau.getCases()[0][0].getMachine().getDirection();
    jeu.rotateSelection();
    assert plateau.getCases()[0][0].getMachine().getDirection() == first.nextClockwise();
    jeu.erase(0,0);
    assert plateau.getCases()[0][0].getMachine() == null;
    jeu.setBuildMode(Jeu.BuildMode.MINE); jeu.press(1,15);
    assert plateau.getCases()[1][15].getMachine() instanceof Mine;
    for (int i=0;i<100;i++) plateau.run();
    ItemShape item = new ItemShape(ItemShape.ShapeType.SQUARE);
    ItemShape right = item.Cut();
    assert item.getPart() == ItemShape.Part.LEFT && right.getPart() == ItemShape.Part.RIGHT;
    item.rotate(); assert item.getPart() != ItemShape.Part.LEFT;
    item.Color(modele.item.Color.Blue); assert item.getColor() == modele.item.Color.Blue;
    item.stack(right); assert item.getStackedTop() != null;
    assert Assets.url("data/sprites/buildings/miner.png") != null;
    ImagePanel panel = new ImagePanel(); panel.setShape(item); panel.setSize(90,90);
    BufferedImage image = new BufferedImage(90,90,BufferedImage.TYPE_INT_ARGB);
    panel.paint(image.getGraphics());
    System.out.println("ShapeCraft : pose, rotation, suppression, mine, simulation, découpe, couleur, empilage et rendu Swing hors écran OK");
  }
}
