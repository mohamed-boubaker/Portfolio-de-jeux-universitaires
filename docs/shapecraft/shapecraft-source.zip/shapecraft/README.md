# ShapeCraft dans le navigateur

Source universitaire : `original/`, révision `cd05cdbd2697cbebcb7ffba42ba94775496bc333` du dépôt https://github.com/mohamed-boubaker/Licence-3-Project----.

Les classes `modele/` de `src/` sont identiques à l'original. Le moteur, les machines, les formes, les règles de livraison et la simulation restent en Java. Les sprites du dépôt sont emballés dans le JAR, sans retouche.

Les seules adaptations concernent l'interface : chargement des images depuis le classpath via `Assets.java`, correction du nom de l'icône de clic gauche, emploi du dessin de couleur existant pour le sprite jaune absent, taille de fenêtre adaptée au bureau Java, boutons plus compacts et retrait de la décoration de fenêtre. Le navigateur utilise CheerpJ 5.0 en Java 21 (le code original emploie notamment `List.getFirst()`). Le runtime est chargé depuis le CDN officiel lors du clic sur Lancer. Son affichage de licence non commerciale est conservé.

## Compilation

Avec un JDK 21 ou plus récent :

```sh
python build.py
```

La sortie est `../dist/shapecraft/shapecraft.jar`. On peut aussi indiquer le compilateur Eclipse ECJ avec `ECJ_JAR=/chemin/ecj.jar`. La page télécharge le JAR complet puis le dépose dans le système de fichiers mémoire `/str/` de CheerpJ avant de le lancer. Le chargement du projet ne dépend donc pas des requêtes HTTP Range de l’hébergement ; les fichiers du runtime restent servis par son CDN officiel.

## Vérifications

`tests/TestModel.java` vérifie la pose, la rotation, la suppression, les mines, 100 pas de simulation, la découpe, la coloration, l'empilage, le chargement des sprites et un rendu Swing hors écran. Compiler ce test avec le JAR dans le classpath puis lancer Java avec `-ea -Djava.awt.headless=true`.

La compilation et ces tests ne remplacent pas un essai du runtime Java dans un navigateur. Documentation officielle : https://cheerpj.com/docs/getting-started/Java-app.

## Alignement de la souris

L’affichage CheerpJ utilise désormais `cheerpjCreateDisplay(-1, -1, stage)` et un conteneur dimensionné en pixels CSS réels, sans transformation `scale`. La fenêtre Swing suit la taille du bureau Java ; sa barre de machines utilise une grille sans retour de ligne. Le redimensionnement de la page et le plein écran n’appliquent donc plus une réduction visuelle extérieure aux coordonnées des clics.
