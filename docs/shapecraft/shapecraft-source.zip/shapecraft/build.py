"""Compiler les classes Java et emballer leurs sprites. JDK 21+ ou ECJ."""
from pathlib import Path
import os, subprocess, zipfile

root = Path(__file__).resolve().parent
classes = root / 'classes'
classes.mkdir(exist_ok=True)
sources = list(map(str, (root / 'src').rglob('*.java')))
if os.environ.get('ECJ_JAR'):
    command = ['java', '-jar', os.environ['ECJ_JAR'], '-21', '-warn:none']
else:
    command = ['javac', '--release', '21']
subprocess.run(command + ['-encoding', 'UTF-8', '-d', str(classes)] + sources, check=True)
target = root.parent / 'dist/shapecraft/shapecraft.jar'
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\nMain-Class: Main\n\n')
    for p in classes.rglob('*.class'): z.write(p, p.relative_to(classes))
    for p in (root / 'original/data').rglob('*'):
        if p.is_file(): z.write(p, p.relative_to(root / 'original'))
print(target)
