package vuecontroleur;

import java.net.URL;

/** Les sprites sont emballés dans le JAR pour fonctionner aussi dans le navigateur. */
public final class Assets {
    private Assets() { }
    public static URL url(String path) {
        String resource = path.startsWith("./") ? path.substring(2) : path;
        URL found = Assets.class.getClassLoader().getResource(resource);
        if (found == null) throw new IllegalArgumentException("Ressource absente : " + resource);
        return found;
    }
}
