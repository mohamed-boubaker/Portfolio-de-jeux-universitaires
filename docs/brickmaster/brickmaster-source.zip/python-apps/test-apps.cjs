const fs = require('node:fs');
const path = require('node:path');
const { loadPyodide } = require(process.env.PYODIDE_MODULE || 'pyodide');
const root = path.resolve(__dirname, '..');
(async () => {
  const py = await loadPyodide();
  await py.loadPackage(path.join(root, 'dist/python-runtime/markupsafe-3.0.3-cp314-cp314-pyemscripten_2026_0_wasm32.whl'));
  await py.loadPackage(path.join(root, 'dist/python-runtime/jinja2-3.1.6-py3-none-any.whl'));
  py.runPython(fs.readFileSync(path.join(__dirname, 'runtime.py'), 'utf8'));
  for (const name of ['brickmaster', 'morpion']) {
    py.globals.set('payload', fs.readFileSync(path.join(root, `dist/${name}/app-data.json`), 'utf8'));
    py.globals.set('app_name', name);
    py.runPython(`
result = json.loads(boot(payload, '/' + app_name))
assert '<html' in result['html'].lower()
for route in APP.routes:
    result = APP.request(route)
    assert '<html' in result['html'].lower(), route
print(app_name, ': toutes les pages GET sont rendues')
`);
    if (name === 'brickmaster') py.runPython(`
APP.request('choix', {'valider':['1'], 'nom_utilisateur':['Test portfolio'], 'avatar':['static/img/avatar1.png']})
assert APP.session['UTILISATEUR'] == 'Test portfolio'
APP.request('tab', {'grille_creer':['1'], 'longueur':['9'], 'largeur':['9']})
assert len(APP.session['grille']) == 9
APP.session['grille'] = [[0]*9 for _ in range(9)]
piece = APP.connection.db.execute('SELECT * FROM piece WHERE id=1').fetchone()
APP.session['pioche'][0] = piece[0]; APP.session['couleur'][0] = piece
APP.request('tab', {'place_brique':['1'], 'brique':[str(piece[0])], 'position_x':['0'], 'position_y':['0']})
assert APP.session['message'] == 'Pièce posée !', APP.session['message']
assert APP.session['grille'][0][0] == piece[4]
before = [row[:] for row in APP.session['grille']]
piece = APP.session['couleur'][0]
APP.request('tab', {'place_brique':['1'], 'brique':[str(piece[0])], 'position_x':['8'], 'position_y':['8']})
assert APP.session['grille'] == before or (piece[1] == 1 and piece[2] == 1)
for size in range(3,17):
    APP.request('tab', {'grille_creer':['1'], 'longueur':[str(size)], 'largeur':[str(size)]})
assert len(APP.session['grille']) == 16
print('BrickMaster : connexion, génération, placement, bornes et dimensions OK')
`);
    else py.runPython(`
APP.request('config', {'bouton_ajouter_config':['1'], 'id_config':['TEST'], 'taille_grille':['4'], 'nb_tours':['50']})
assert APP.connection.db.execute("SELECT taille_de_grille FROM config WHERE id_config='TEST'").fetchone()[0] == 4
APP.request('Jeu', {'bouton_lancer':['1'], 'choix_equipe1':['#357DB8'], 'choix_equipe2':['#D17835'], 'choix_config':['DEMO_3X3']})
assert 'game_id' in APP.session
game = APP.session['game_id']
for x,y in [(0,0),(1,0),(0,1),(1,1),(0,2)]:
    page = APP.request('plateau')
    assert 'Choisis ton combattant' in page['html']
    turns = APP.connection.db.execute('SELECT COUNT(*) FROM journal WHERE idpartie=?',(game,)).fetchone()[0]
    color = ['#357DB8','#D17835'][turns % 2]
    names = [r[0] for r in APP.connection.db.execute('SELECT nom FROM possede WHERE couleur=?',(color,))]
    used = {r[0] for r in APP.connection.db.execute('SELECT nom_morpion FROM morpion_actif WHERE idpartie=?',(game,))}
    selected = next(n for n in names if n not in used)
    APP.request('plateau', {'btn_jouer_case':[f'{x},{y}'], 'choix_img':[selected]})
assert APP.connection.db.execute('SELECT gagnant FROM partie WHERE idpartie=?',(game,)).fetchone()[0] == '#357DB8'
assert 'VICTOIRE' in APP.request('plateau')['html']
history = APP.request('historique', {'bouton_generer':['1']})
assert history['downloads']
# Rejouer une partie et résoudre un combat via les formulaires originaux.
APP.request('Jeu', {'bouton_lancer':['1'], 'choix_equipe1':['#357DB8'], 'choix_equipe2':['#D17835'], 'choix_config':['DEMO_3X3']})
game2 = APP.session['game_id']
APP.request('plateau', {'btn_jouer_case':['0,0'], 'choix_img':['Pingouin 01']})
APP.request('plateau', {'btn_jouer_case':['1,0'], 'choix_img':['Pingouin 09']})
old_hp = APP.connection.db.execute('SELECT pv_actuel FROM morpion_actif WHERE idpartie=? AND x=1 AND y=0',(game2,)).fetchone()[0]
APP.request('plateau', {'btn_select_pion':['0,0']})
APP.request('plateau', {'btn_action':['attaque'], 'src_x':['0'], 'src_y':['0']})
assert 'action_en_cours' in APP.session
import random
saved_randint = random.randint
random.randint = lambda a,b: 100
APP.request('plateau', {'btn_select_pion':['1,0']})
random.randint = saved_randint
new_hp = APP.connection.db.execute('SELECT pv_actuel FROM morpion_actif WHERE idpartie=? AND x=1 AND y=0',(game2,)).fetchone()[0]
assert new_hp < old_hp
APP.request('ajouter', {'bouton_valider':['1'], 'nom_equipe':['Équipe test'], 'couleur_equipe':['#557744'], 'choix_morpions':[f'Pingouin {i:02d}' for i in range(1,7)]})
assert APP.connection.db.execute("SELECT COUNT(*) FROM possede WHERE couleur='#557744'").fetchone()[0] == 6
APP.request('afficher', {'bouton_supprimer':['1'], 'couleur_a_supprimer':['#557744']})
assert APP.connection.db.execute("SELECT COUNT(*) FROM equipe WHERE couleur='#557744'").fetchone()[0] == 0
print('Pingouin : pages, configuration, tours, victoire, combat, équipes et historique OK')
`);
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
