// Exécuter le vrai fichier worker en module, avec le Python WASM de production.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');
const { Worker } = require('node:worker_threads');
const root = path.resolve(__dirname, '..');
const pyodideDirectory = path.dirname(require.resolve(process.env.PYODIDE_MODULE || 'pyodide'));

// Vérifier le mode demandé par le vrai code de la page lors du clic de lancement.
const elements = Object.fromEntries(['launch','project-frame','runtime-status','runtime-error','reset','quick-play'].map(id => [id, {
  events: {}, setAttribute() {}, addEventListener(name, callback) { this.events[name] = callback; }
}]));
let workerOptions;
const context = vm.createContext({
  document: { getElementById: id => elements[id] },
  location: { href: 'https://portfolio.example/brickmaster/' },
  URL,
  Worker: class { constructor(url, options) { workerOptions = options; } postMessage() {} }
});
vm.runInContext(fs.readFileSync(path.join(root,'dist/python-runtime/app.js'),'utf8'),context);
elements.launch.events.click();
assert.equal(workerOptions?.type, 'module', 'Pyodide exige un worker module');

const temporary = fs.mkdtempSync(path.join(process.env.TEST_WORK_DIRECTORY || require('node:os').tmpdir(), 'portfolio-worker-'));
const production = fs.readFileSync(path.join(root,'dist/python-runtime/worker.js'),'utf8');
const localSource = production
  .replace('https://cdn.jsdelivr.net/pyodide/v314.0.7/full/pyodide.mjs', pathToFileURL(path.join(pyodideDirectory,'pyodide.mjs')).href)
  .replace('https://cdn.jsdelivr.net/pyodide/v314.0.7/full/', pyodideDirectory + '/');
// Node fournit les mêmes messages de worker ; seuls le transport des fichiers
// et le chemin du moteur sont locaux pour ne pas dépendre du réseau dans le test.
const harness = `
import {parentPort} from 'node:worker_threads';
import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
globalThis.self = globalThis;
globalThis.location = {href:${JSON.stringify(pathToFileURL(path.join(root,'dist/python-runtime/worker.js')).href)}};
globalThis.postMessage = message => parentPort.postMessage(message);
globalThis.fetch = async url => new Response(await fs.readFile(fileURLToPath(url)));
${localSource}
parentPort.on('message',data => self.onmessage({data}));
`;
const moduleFile = path.join(temporary,'worker.mjs'); fs.writeFileSync(moduleFile,harness);

(async () => {
  try {
    for (const app of ['brickmaster','morpion']) {
      const worker = new Worker(pathToFileURL(moduleFile), { type: 'module' });
      const pending = new Map(); let id = 0;
      const send = data => new Promise((resolve,reject) => {
        const key = ++id;
        const timer = setTimeout(() => reject(new Error('Délai dépassé au démarrage du worker')), 60000);
        pending.set(key,{ resolve,reject,timer }); worker.postMessage({...data,id:key});
      });
      worker.on('message', data => {
        if (data.progress) return;
        const job = pending.get(data.id); if (!job) return;
        clearTimeout(job.timer); pending.delete(data.id);
        if (data.error) job.reject(new Error(data.error)); else job.resolve(data.result);
      });
      worker.on('error', error => { for (const job of pending.values()) {clearTimeout(job.timer);job.reject(error);} });
      try {
        let result = await send({type:'boot',base:'/'+app,payloadURL:pathToFileURL(path.join(root,`dist/${app}/app-data.json`)).href});
        assert(result.html.includes('<html'));
        if (app === 'brickmaster') {
          result = await send({route:'tab',post:{grille_creer:['1'],longueur:['9'],largeur:['9']}});
          assert(result.html.includes('Le plateau BrickMaster'));
          result = await send({route:'choix',post:{valider:['1'],nom_utilisateur:['Test worker module'],avatar:['static/img/avatar1.png']}});
          assert(result.html.includes('Test worker module'));
        } else {
          result = await send({route:'Jeu',post:{bouton_lancer:['1'],choix_equipe1:['#357DB8'],choix_equipe2:['#D17835'],choix_config:['DEMO_3X3']}});
          assert.equal(result.route,'plateau');
          assert(result.html.includes('Équipe Azur'));
        }
        console.log(`${app} : lancement via worker module, données et formulaires OK`);
      } finally { await worker.terminate(); }
    }
  } finally { fs.rmSync(temporary,{recursive:true,force:true}); }
})().catch(error => {console.error(error);process.exitCode=1;});
