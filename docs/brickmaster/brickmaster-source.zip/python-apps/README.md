# BrickMaster et Pingouin Morpion — intégration des applications Python

Sources universitaires dans `original/`, copiées de https://github.com/mohamed-boubaker/Licence-2-Project-- à la révision `6b23a30f3f9ee6cae13e3219c0b311eee437d1e4`. Les crédits et les images des projets sont conservés.

`adapted/` contient les versions adaptées des contrôleurs, modèles et templates. `runtime.py` remplace l'infrastructure BDW manquante par un adaptateur exécuté dans Pyodide : les vrais fichiers Python sont importés et exécutés, et les templates originaux rendus avec Jinja2. Le JavaScript gère le chargement et transmet les formulaires ; il ne réécrit pas les règles de jeu.

## Base de données et portée

Le moteur PostgreSQL n'est pas lancé dans cette intégration. Chaque onglet possède une base SQLite en mémoire, isolée, et une session Python. L'adaptateur traduit les schémas, les placeholders psycopg, `NOW`, `strpos`, les dates et les insertions `DEFAULT` nécessaires. Les modèles conservent leurs requêtes d'origine, sauf une correction d'alias dans BrickMaster.

Les données sont locales et réinitialisées au rechargement. Il n'y a pas de serveur de parties partagées ni de synchronisation entre appareils. Pingouin se joue à deux sur le même appareil.

- **BrickMaster** : reprise du SQL fourni (1280 pièces et données d'exemple). Correction d'une clé de tour dupliquée dans les données lors de l'import, de la comparaison de noms, d'une faute de variable de session et de l'alias de comptage. La génération de grille et le placement ont été bornés pour éviter les boucles infinies ; le placement utilise la dimension et la couleur de la pièce choisie, et la pioche reste cohérente. Le template de grille et la mise en page ont été adaptés. Le helper `includes.py` absent est repris du second projet.
- **Pingouin Morpion** : conservation des contrôleurs, des modèles et des règles de combat/victoire. Le template de plateau affiche un lien de lancement en l'absence de partie. Le SQL du dépôt ne contenant aucune ligne, l'adaptateur ajoute **des données de démonstration**, sans prétendre reconstituer le catalogue d'origine : 16 personnages avec les sprites fournis, deux équipes de 8 et une configuration 3 × 3. Les équipes et configurations peuvent être créées dans les pages originales.

## Construire les paquets

```sh
python build.py
```

Cela produit les `app-data.json` et copie les ressources statiques vers `../dist/brickmaster/` et `../dist/morpion/`. Le moteur de navigateur est dans `../dist/python-runtime/`. Pyodide v314.0.7 est chargé depuis le CDN officiel à la demande ; les roues Jinja2 et MarkupSafe sont hébergées avec le site.

## Tests

Installer le package npm `pyodide@314.0.7`, puis :

```sh
node test-apps.cjs
```

`PYODIDE_MODULE` peut désigner un module installé ailleurs. Le test utilise le même Python WebAssembly et les mêmes paquets que le navigateur. Il couvre les pages, la connexion, les grilles, les placements et limites, la configuration d'une partie, les tours, les placements de pions, la victoire, les combats, la création/suppression d’équipes et l’export de l’historique.

Les modifications SQL et la base locale sont des adaptations de déploiement ; cette version ne remplace pas l'environnement PostgreSQL/BDW du cours.

Le lancement Pyodide utilise un worker **module** avec import ESM de `pyodide.mjs`. Pyodide v314 ne prend plus en charge les workers classiques ; ce démarrage est couvert par `test-worker.cjs`, en plus des tests de contrôleurs.
