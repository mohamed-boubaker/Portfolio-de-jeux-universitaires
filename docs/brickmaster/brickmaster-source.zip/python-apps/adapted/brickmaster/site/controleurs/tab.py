from model.model_pg import get_instances, random_bd
from random import randint

def init_grille(longueur=10, largeur=10):
    #init à 0 de toutes les cases = vides
    grille = []
    for i in range(longueur):
        print(i)
        grille.append([])
        for j in range(largeur):
            grille[i].append(0)
    return grille

def trouve_vide(grille, i, j):
    from random import randint
    directions = [(0,1), (1,0), (0,-1), (-1,0)] #les directions possibles pour trouver une case vide
    k = randint(0,3)
    while(grille[i+directions[k][0]][j+directions[k][1]] != 0): #tests des différentes directions
        k = randint(0,3)
        print(directions[k])
    print("sorti du while ici")
    return directions[k]

def danslagrille(longueur, largeur, i, j):
    return 0 <= i < longueur and 0 <= j < largeur


def aleatoire_grille(grille, longueur, largeur, danslagrille=danslagrille):
    from random import choice, randint
    count = randint(max(1, longueur * largeur // 10), max(1, longueur * largeur // 5))
    frontier = {(randint(0, longueur - 1), randint(0, largeur - 1))}
    for _ in range(count):
        if not frontier: break
        x, y = choice(sorted(frontier)); frontier.remove((x, y))
        grille[x][y] = 1
        for dx, dy in [(0,1),(1,0),(0,-1),(-1,0)]:
            nx, ny = x + dx, y + dy
            if danslagrille(longueur, largeur, nx, ny) and grille[nx][ny] == 0:
                frontier.add((nx, ny))
    return grille




"""def aleatoire_grille(grille, longueur, largeur, trouve_vide = trouve_vide):
    from random import randint
    ibase = randint(0, longueur)
    jbase = randint(0, largeur)
    for i in range(0, randint(int(0.1*(longueur*largeur)),int(0.2*(largeur*longueur)))):
        if(grille[ibase][jbase] == 0):
            grille[ibase][jbase] = 1
        else:
            l, j = trouve_vide(grille, ibase, jbase)
            grille[l][j] = 1
            ibase = l
            jbase = j
            print(ibase, jbase)
    return grille"""

def changement(grille, largeur, longueur, posx, posy, lcase, lacase, colcase, danslagrille=danslagrille):
    if not danslagrille(longueur, largeur, posx, posy) or not danslagrille(longueur, largeur, posx+lcase-1, posy+lacase-1):
        return "erreur"
    cells = [(i,j) for i in range(posx,posx+lcase) for j in range(posy,posy+lacase)]
    if any(grille[i][j] not in (0, 1) for i,j in cells): return "déjà remplis"
    for i,j in cells: grille[i][j] = colcase
    return "cc"



if 'grille' not in SESSION:
    SESSION['longueur'] = SESSION['largeur'] = 9
    SESSION['grille'] = aleatoire_grille(init_grille(9,9),9,9)

if 'grille_creer' in POST: #vérifie si la grille est créée
    SESSION['longueur'] = max(3, min(16, int(POST['longueur'][0])))
    SESSION['largeur'] = max(3, min(16, int(POST['largeur'][0])))
    print(SESSION['longueur'])
    print(SESSION['largeur'])
    SESSION["grille"] = init_grille(SESSION['longueur'], SESSION['largeur'])
    print(SESSION["grille"])
    SESSION["grille"] = aleatoire_grille(SESSION['grille'], SESSION['longueur'], SESSION['largeur'])


if 'pioche' not in SESSION: #si la pioche n'est pas créée
    SESSION['pioche'] = []
    SESSION['couleur'] = []
    res = random_bd(SESSION['CONNEXION'], 'piece') #retourne toute une ligne avce toutes les infos sur la brique trouvée de manière aléatoire
    SESSION['pioche'].append(res[0][0]) #append uniquement le numéro de la pièce
    SESSION['couleur'].append(res[0]) #append toute la ligne, pour de bas ey utilisé pour les couleurs mais aussi sa taille ect
    res1 = random_bd(SESSION['CONNEXION'], 'piece')
    SESSION['pioche'].append(res1[0][0])
    SESSION['couleur'].append(res1[0])
    res2 = random_bd(SESSION['CONNEXION'], 'piece')
    SESSION['pioche'].append(res2[0][0])
    SESSION['couleur'].append(res2[0])
    res3 = random_bd(SESSION['CONNEXION'], 'piece')
    SESSION['pioche'].append(res3[0][0])
    SESSION['couleur'].append(res3[0])
print(SESSION['couleur'])

if 'c' in POST:
    try:
        index = SESSION['pioche'].index(int(POST['c'][0]))
        piece = random_bd(SESSION['CONNEXION'], 'piece')[0]
        SESSION['pioche'][index] = piece[0]
        SESSION['couleur'][index] = piece
        SESSION['message'] = "Pièce échangée."
    except (ValueError, IndexError): SESSION['message'] = "Choisissez une pièce de la pioche."

if 'place_brique' in POST:
    try:
        index = SESSION['pioche'].index(int(POST['brique'][0]))
        piece = SESSION['couleur'][index]
        result = changement(SESSION['grille'], SESSION['largeur'], SESSION['longueur'],
            int(POST['position_x'][0]), int(POST['position_y'][0]), piece[2], piece[1], piece[4])
        if result == 'cc':
            replacement = random_bd(SESSION['CONNEXION'], 'piece')[0]
            SESSION['pioche'][index] = replacement[0]
            SESSION['couleur'][index] = replacement
            SESSION['message'] = 'Pièce posée !'
        else: SESSION['message'] = 'Cette pièce sort du plateau ou chevauche une autre pièce.'
    except (ValueError, IndexError, KeyError): SESSION['message'] = 'Vérifiez la pièce et sa position.'
