from pathlib import Path
import json, shutil, tomllib

root = Path(__file__).resolve().parents[1]
for app in ['brickmaster', 'morpion']:
    folder = root / 'python-apps/adapted' / app / 'site'
    if not folder.exists(): continue
    target = root / 'dist' / app
    target.mkdir(parents=True, exist_ok=True)
    shutil.copytree(folder / 'static', target / 'static', dirs_exist_ok=True)
    files = {str(p.relative_to(folder)): p.read_text() for p in folder.rglob('*.py')}
    templates = {str(p.relative_to(folder / 'templates')): p.read_text() for p in (folder / 'templates').rglob('*.html')}
    routes = {x['url']: x for x in tomllib.loads((folder / 'routes.toml').read_text())['routes'] if (folder / x['controleur']).exists()}
    schema = (folder.parent / 'database/schema.sql' if app == 'morpion' else folder / 'bd-projet.sql').read_text()
    (target / 'app-data.json').write_text(json.dumps(dict(app=app, files=files, templates=templates, routes=routes, schema=schema), ensure_ascii=False))
shutil.copy(root / 'python-apps/runtime.py', root / 'dist/python-runtime/runtime.py')
print('Paquets Python, templates et ressources construits.')
